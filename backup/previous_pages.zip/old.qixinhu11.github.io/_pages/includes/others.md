# 📖 Educations
- *2020.09 - 2023.06 (now)*, Master, HUST, Wuhan, China.
- *2016.09 - 2020.06*, Undergraduate, HUST, Wuhan, China.

# 🎖 Honors and Awards
- *2021.10* Outstanding Graduate Student.
- *2020.06* Honored Undergraduates.
- *2018.10* National Encouragement Scholarship. 

# 📄 Patents
- Non-line-of-sight object identification method, system and device. \\
  Wang Xingze, **Qixin Hu**. \\
  Granted on March 28, 2022; CN114202685A.


# 💻 Internships and Experiences

- *2019.04 - 2020.04*, **Team Learder**, National Student Innovation and Entrepreneurship Training Program, HUST, advised By [Prof. Ming Yang](http://phys.hust.edu.cn/info/1225/2480.htm)

- *2021.06 - 2021.09*, **Research Intern**, Tsinghua University, advised by [Prof. Yebin Liu](http://www.liuyebin.com/)

- *2022.05 - 2022.11*, **Research Intern**, Northeastern University, advised by [Prof. Huaizu Jiang](http://jianghz.me/)

- *2022.06 - now*, **Research Intern**, Johns Hopkins University, co-advised by [Prof. Alan Yuille](https://scholar.google.com/citations?user=FJ-huxgAAAAJ&hl=en) and [Dr. Zongwei Zhou](https://www.zongweiz.com/).
