# 📝 Publications 

<div class='paper-box'><div class='paper-box-image'><div><div class="badge">CVPR 2023</div><img src='images/paradigm_shift.png' alt="sym" width="100%"></div></div>
<div class='paper-box-text' markdown="1">

***Label-Free Liver Tumor Segmentation***  \\
**Qixin Hu**, Yixiong Chen, Junfei Xiao, Shu Wen Sun, Jieneng Chen, Alan Yuille, Zongwei Zhou.

[**Paper**](https://arxiv.org/pdf/2210.14845.pdf) \| [**Code**](https://github.com/MrGiovanni/SyntheticTumors) \| [**Slides**](https://www.zongweiz.com/_files/ugd/deaea1_847722d9a32342c785cfbb01f8843b2e.pdf) \| [**Poster**](https://www.zongweiz.com/_files/ugd/deaea1_8f7c1cd2f2cc4c559a7cc2d6ce5e6cf5.pdf) \| [**Talk**](https://www.youtube.com/watch?v=bJpI9tCTsuA)
</div>
</div>

<div class='paper-box'><div class='paper-box-image'><div><div class="badge">NeurIPS workshop 2022</div><img src='images/livertumorturing.png' alt="sym" width="100%"></div></div>
<div class='paper-box-text' markdown="1">

***Synthetic Tumors Make AI Segment Tumors Better***  \\
**Qixin Hu**, Junfei Xiao, Yixiong Chen, Shuwen Sun, Jie-Neng Chen, Alan Yuille, Zongwei Zhou.

[**Paper**](https://arxiv.org/pdf/2210.14845.pdf) \| [**Code**](https://github.com/MrGiovanni/SyntheticTumors) \| [**Slides**](https://www.zongweiz.com/_files/ugd/deaea1_847722d9a32342c785cfbb01f8843b2e.pdf) \| [**Poster**](https://www.zongweiz.com/_files/ugd/deaea1_8f7c1cd2f2cc4c559a7cc2d6ce5e6cf5.pdf) \| [**Talk**](https://www.youtube.com/watch?v=bJpI9tCTsuA)
</div>
</div>


<div class='paper-box'><div class='paper-box-image'><div><div class="badge">APL 2021</div><img src='images/speckle.png' alt="sym" width="100%"></div></div>
<div class='paper-box-text' markdown="1">

[***Object recognition for remarkably small field-of-view with speckles***](https://aip.scitation.org/doi/abs/10.1063/5.0040343)  \\
**Qixin Hu**, Siyan Xu, Xue-wen Chen, Xinggang Wang, Ken Xingze Wang.

</div>
</div>



<!-- [Object recognition for remarkably small field-of-view with speckles](https://aip.scitation.org/doi/abs/10.1063/5.0040343)

**Qixin Hu**, Siyan Xu, Xue-wen Chen, Xinggang Wang, Ken Xingze Wang. **APL 2021**. -->

<!-- [Synthetic Tumors Make AI Segment Tumors Better](https://arxiv.org/pdf/2210.14845.pdf)

**Qixin Hu**, Junfei Xiao, Yixiong Chen, Shuwen Sun, Jie-Neng Chen, Alan Yuille, Zongwei Zhou. **NeurIPS workshop 2022** -->

<!-- [Label-Free Liver Tumor Segmentation](https://github.com/MrGiovanni/SyntheticTumors)

**Qixin Hu**, Yixiong Chen, Junfei Xiao, Shu Wen Sun, Jieneng Chen, Alan Yuille, Zongwei Zhou. **CVPR 2023** -->
