---
permalink: /
title: ""
excerpt: ""
author_profile: true
redirect_from: 
  - /about/
  - /about.html
---

{% if site.google_scholar_stats_use_cdn %}
{% assign gsDataBaseUrl = "https://cdn.jsdelivr.net/gh/" | append: site.repository | append: "@" %}
{% else %}
{% assign gsDataBaseUrl = "https://raw.githubusercontent.com/" | append: site.repository | append: "/" %}
{% endif %}
{% assign url = gsDataBaseUrl | append: "google-scholar-stats/gs_data_shieldsio.json" %}

<span class='anchor' id='about-me'></span>

{% include_relative includes/intro.md %}

<font color=red>I am actively looking for a Ph.D. position, long-term research internship/research assistant, and collaborations. Please feel free to contact me at *hqx11@hust.edu.cn* or *qixinhu98@gmail.com* </font> 

{% include_relative includes/pub.md %}

{% include_relative includes/others.md %}
